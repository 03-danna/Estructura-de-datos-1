
public class Main {

    public static void main(String[] args) {

        // =================================
        // 1. VARIABLES PRIMITIVAS
        // =================================

        int semestre = 3;
        double notaMinima = 3.0;
        boolean activo = true;


        // =================================
        // 2. CREACION DE OBJETOS ESTUDIANTE
        // =================================

        Estudiante estudiante1 =
                new Estudiante("Laura", 20, 4.2);

        Estudiante estudiante2 =
                new Estudiante("Carlos", 22, 3.8);


        // =================================
        // 3. DOS REFERENCIAS AL MISMO OBJETO
        // =================================

        Estudiante copia = estudiante1;

        copia.setPromedio(4.8);

        System.out.println("Promedio estudiante1: "
                + estudiante1.getPromedio());

        System.out.println("Promedio copia: "
                + copia.getPromedio());


        // =================================
        // 4. LLAMADA A UN METODO
        // =================================

        procesarEstudiante(estudiante2);


        // =================================
        // 5. REFERENCIAS NULL
        // =================================

        estudiante1 = null;
        copia = null;


        // =================================
        // 6. RETO DE PROGRAMACION: PRODUCTOS
        // =================================

        System.out.println("\n===== RETO DE PRODUCTOS =====");

        // Crear tres productos

        Producto producto1 =
                new Producto(101, "Portatil", 2500000);

        Producto producto2 =
                new Producto(102, "Mouse", 50000);

        Producto producto3 =
                new Producto(103, "Teclado", 120000);


        // Segunda referencia al primer producto

        Producto copiaProducto = producto1;


        // Modificar el precio mediante la segunda referencia

        copiaProducto.actualizarPrecio(2800000);


        // Comprobar el cambio mediante la primera referencia

        System.out.println("Precio producto1: "
                + producto1.getPrecio());

        System.out.println("Precio copiaProducto: "
                + copiaProducto.getPrecio());


        // Mostrar los tres productos

        System.out.println("\nDatos de los productos:");

        producto1.mostrarProducto();

        producto2.mostrarProducto();

        producto3.mostrarProducto();


        // Asignar null a las dos referencias del primer producto

        producto1 = null;
        copiaProducto = null;


        // =================================
        // 7. GARBAGE COLLECTOR
        // =================================

        System.gc();

        System.out.println("\nPrograma finalizado.");

    }


    // =================================
    // 8. METODO PROCESAR ESTUDIANTE
    // =================================

    public static void procesarEstudiante(Estudiante estudiante) {

        int puntosExtra = 1;

        double nuevoPromedio =
                estudiante.getPromedio() + 0.2;

        estudiante.setPromedio(nuevoPromedio);

        estudiante.mostrarDatos();

        System.out.println("Puntos extra: " + puntosExtra);

    }

}
